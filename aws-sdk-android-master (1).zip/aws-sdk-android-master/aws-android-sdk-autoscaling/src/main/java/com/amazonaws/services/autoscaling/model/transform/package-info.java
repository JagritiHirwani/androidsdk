/**
 * Marhsalling for the various types represented byAmazonAutoScaling
 */

package com.amazonaws.services.autoscaling.model.transform;

